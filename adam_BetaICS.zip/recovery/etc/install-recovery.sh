#!/system/bin/sh
if ! applypatch -c MTD:/dev/null:4288512:a40d46c2b2da54635708ea11660eb96539951f6e; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:3950592:35d906988c2e6a385e364e4a6445760ee605ebd4 MTD:/dev/null a40d46c2b2da54635708ea11660eb96539951f6e 4288512 35d906988c2e6a385e364e4a6445760ee605ebd4:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
