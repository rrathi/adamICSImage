#!/system/bin/sh
if ! applypatch -c MTD:recovery:2048:2be8eef49066968fa0fbf986ca05a669eaea414e; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:3135488:34a90eb959a35f942c32fce3020a493df5ff0b99 MTD:recovery cec09769ad9315ad16943907f1eea7ad83c02408 3473408 34a90eb959a35f942c32fce3020a493df5ff0b99:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
